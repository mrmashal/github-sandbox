# Minimal Termux Repository

This repository contains wget and tar packages for Termux 0.119.0-beta.3.

## Setup Instructions

1. Copy the repository to your device
2. Add the repository to Termux:

```bash
# Import GPG key
cat public.key | apt-key add -

# Add repository (adjust path as needed)
echo "deb [trusted=yes] file:///path/to/termux-repo stable main" > $PREFIX/etc/apt/sources.list.d/local-repo.list

# Update and install
apt update
apt install wget tar
```

## Packages Included

- wget
- tar
- All required dependencies

Generated: Sun May  3 13:29:26 UTC 2026
